CLASSPATH=${CLASSPATH};${DOMAIN_HOME}/partnerConfigs/region_AU.properties;${DOMAIN_HOME}/partnerConfigs/region_HK.properties;${DOMAIN_HOME}/partnerConfigs/region_ID.properties;${DOMAIN_HOME}/partnerConfigs/region_KR.properties;${DOMAIN_HOME}/partnerConfigs/region_MY.properties;${DOMAIN_HOME}/partnerConfigs/region_NZ.properties;${DOMAIN_HOME}/partnerConfigs/region_PH.properties;${DOMAIN_HOME}/partnerConfigs/region_SG.properties;${DOMAIN_HOME}/partnerConfigs/region_TH.properties;

echo "********gbabu-7*************"${CLASSPATH}

Environment class path edit location:

file name: commEnv.sh

/wlserver_12.1/server/bin/setWLSEnv.sh 
$WORKSPACE_HOME/tools/weblogic 
export WORKSPACE_HOME=/home/weblogic/workspace

/home/weblogic/workspace/tools/weblogic/wlserver_12.1/server/bin
export DOMAIN_HOME=$WORKSPACE_HOME/runtime/vsp_domain 


DOMAIN_HOME="/opt/weblogic/user_projects/domains/vitality_service_portal_domain"
DOMAIN_HOME=$WORKSPACE_HOME/runtime/vsp_domain


/opt/weblogic/wlserver_12.1/common/bin  - commEnv.sh
# set up WebLogic Server's class path  - edit name

/opt/weblogic/user_projects/domains/vitality_service_portal_domain/servers/myserver/cache
start weblogic - /home/weblogic/workspace/bin
				 nohup ./start.sh &
				 
				 
log locaiton: /home/weblogic/workspace/logs/myserver				 


${CLASSPATHSEP}

JAVA_HOME=/opt/jdk1.8.0_231
PATH=$JAVA_HOME/bin:$PATH

PATH=$PATH:$HOME/bin
export PATH


CLASSPATH=$CLASSPATH/opt/weblogic/user_projects/domains/vitality_service_portal_domain/partnerConfigs/region_PH.properties

CLASSPATH=/opt/weblogic/user_projects/domains/vitality_service_portal_domain/partnerConfigs/region_PH.properties




${CLASSPATHSEP}${DOMAIN_HOME}/partnerConfigs/region_AU.properties
${CLASSPATHSEP}${DOMAIN_HOME}/partnerConfigs/region_HK.properties
${CLASSPATHSEP}${DOMAIN_HOME}/partnerConfigs/region_ID.properties
${CLASSPATHSEP}${DOMAIN_HOME}/partnerConfigs/region_KR.properties
${CLASSPATHSEP}${DOMAIN_HOME}/partnerConfigs/region_MY.properties
${CLASSPATHSEP}${DOMAIN_HOME}/partnerConfigs/region_NZ.properties
--${CLASSPATHSEP}${DOMAIN_HOME}/partnerConfigs/region_PH.properties
${CLASSPATHSEP}${DOMAIN_HOME}/partnerConfigs/region_SG.properties
--${CLASSPATHSEP}${DOMAIN_HOME}/partnerConfigs/region_TH.properties




JAVA_HOME=/opt/jdk1.8.0_231
PATH=$JAVA_HOME/bin:$PATH



MAVEN_HOME=/opt/apache-maven-3.6.2
PATH=$MAVEN_HOME/bin:$PATH

#MAVEN_HOME=/opt/.jenkins/apache-maven-3.2.1
#PATH=$MAVEN_HOME/bin:$PATH


ANT_HOME=/opt/apache-ant-1.9.14
PATH=$ANT_HOME/bin:$PATH





${CLASSPATHSEP}/opt/weblogic/user_projects/domains/vitality_service_portal_domain/partnerConfigs/region_AU.properties${CLASSPATHSEP}/opt/weblogic/user_projects/domains/vitality_service_portal_domain/partnerConfigs/region_HK.properties${CLASSPATHSEP}/opt/weblogic/user_projects/domains/vitality_service_portal_domain/partnerConfigs/region_ID.properties${CLASSPATHSEP}/opt/weblogic/user_projects/domains/vitality_service_portal_domain/partnerConfigs/region_KR.properties${CLASSPATHSEP}/opt/weblogic/user_projects/domains/vitality_service_portal_domain/partnerConfigs/region_MY.properties${CLASSPATHSEP}/opt/weblogic/user_projects/domains/vitality_service_portal_domain/partnerConfigs/region_NZ.properties${CLASSPATHSEP}/opt/weblogic/user_projects/domains/vitality_service_portal_domain/partnerConfigs/region_SG.properties